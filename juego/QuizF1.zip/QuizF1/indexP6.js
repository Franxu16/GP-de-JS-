function mostrarPista1(){
    alert('Esa temporada se introdujeron medidas de seguridad bastante grandes');
}
function mostrarPista2(){
    alert('Hubo cambios en los motores que se introdujeron la primera vez el año anterior');
}
function mostrarPista3(){
    alert('La pandemia casi acaba con esta temporada aunque duró bastantes mas carreras de las que se esperaba');
}
function mostrarPista4(){
    alert('El fin de una era en el deporte');
}