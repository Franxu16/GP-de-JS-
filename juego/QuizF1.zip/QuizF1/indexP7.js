function mostrarPista1(){
    alert('Han tenido pilotos jovenes desde la decada pasada, aunque con maquinaria pobre');
}
function mostrarPista2(){
    alert('Uno de sus pilotos le compitió a Fernando Alonso la victoria en Malasia 2012');
}
function mostrarPista3(){
    alert('Han tenido siempre a los mejores pilotos de sus generaciones, desde su fundador hasta el 7 veces campeón del mundo del siglo 21');
}
function mostrarPista4(){
    alert('Sus pilotos, pese a su poco potencial, competían a un nivel altisimo');
}