function mostrarPista1(){
    alert('Ha conducido solo para 2 escuderias en toda su carrera');
}
function mostrarPista2(){
    alert('Tambien tiene otros records relacionados con longevidad y puntaje');
}
function mostrarPista3(){
    alert('Llegó en 2019 ha una escudería acabada y en 2 años la remontó');
}
function mostrarPista4(){
    alert('Siempre ha estado en equipos pequeños y solo cuenta con una pole en su carrera');
}