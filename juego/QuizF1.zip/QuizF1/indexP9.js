function mostrarPista1(){
    alert('El "Brake Bias" antes estaba en la misma posición que la palanca de cambios de las cajas de cambios manuales');
}
function mostrarPista2(){
    alert('Esta mejora causó controversia por el modo de activación que tenía');
}
function mostrarPista3(){
    alert('Si una leva se rompía, tenía que abandonar por fallo de la caja de cambios');
}
function mostrarPista4(){
    alert('Los pianos con baches pudieron hacer que la pierna rozara con el cockpit y le acabase picando');
}