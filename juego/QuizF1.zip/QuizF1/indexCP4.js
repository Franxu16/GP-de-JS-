function inicio(){
    alert('PREGUNTA CORRECTA --> 4/10');
}