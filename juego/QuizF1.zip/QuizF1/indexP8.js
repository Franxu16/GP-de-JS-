function mostrarPista1(){
    alert('Se habla mas de un idioma en ese país');
}
function mostrarPista2(){
    alert('Fue en su primer gran premio fue la primera carrera noctura');
}
function mostrarPista3(){
    alert('Ha tenido una de las familias de pilotos mas condecoradas del deporte');
}
function mostrarPista4(){
    alert('Este circuito participó en una de las polemicas mas grandes del deporte por la mala gestión de los neumaticos');
}