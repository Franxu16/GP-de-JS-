function mostrarPista1(){
    alert('Fue el mejor de su generación, se ganó el respeto de todos');
}
function mostrarPista2(){
    alert('De los mas valientes de la época, capaz de enfrentar hasta los peores temporales');
}
function mostrarPista3(){
    alert('Su ego le ayudó a tener una imágen y un mundial');
}
function mostrarPista4(){
    alert('Murió en la flor de la vida y con un potencial muy grande para su época');
}