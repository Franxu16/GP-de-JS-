function inicio(){
    alert('PREGUNTA CORRECTA --> 8/10');
}