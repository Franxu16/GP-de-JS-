function mostrarPista1(){
    alert('Los pilotos esa temporada fueron: Nico Rosberg y Kazuki Nakagima');
}
function mostrarPista2(){
    alert('Esa temporada no consiguieron podios, solo unos pocos puntos');
}
function mostrarPista3(){
    alert('Son un equipo pobre, no tienen presupuesto ni para repuestos');
}
function mostrarPista4(){
    alert('Tienen potencial, con una pareja de pilotos que comienzan a enseñar su potencial');
}