function inicio(){
    alert('PREGUNTA CORRECTA --> 5/10');
}