function mostrarPista1(){
    alert('Dijo esta radio al dejarse adelantar');
}
function mostrarPista2(){
    alert('Esta radio fue dicha en el Gran Premio de Alemania cuando este piloto abandonó');
}
function mostrarPista3(){
    alert('Un choque provocó esta radio');
}
function mostrarPista4(){
    alert('Esta radio la dijo cuando, por un error en el cambio de los reglajes manuales del coche se le caló y se emptró contra el muro');
}