function mostrarPista1(){
    alert('Ganó la carrera dominando');
}
function mostrarPista2(){
    alert('No pudo alcanzar el mismo ritmo que su compañero');
}
function mostrarPista3(){
    alert('Hizo una remontada estelar que le valió para el esa posición');
}