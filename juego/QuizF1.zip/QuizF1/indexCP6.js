function inicio(){
    alert('PREGUNTA CORRECTA --> 6/10');
}