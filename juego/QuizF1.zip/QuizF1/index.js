function mostrarSaludo(){
    alert('Bienvenido al Quiz de la Formula 1');
}
window.onload = function(){
    mostrarSaludo(); //Esta función muestra el mensaje que se ha creado antes
};