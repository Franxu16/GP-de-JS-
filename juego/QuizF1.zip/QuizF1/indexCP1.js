function inicio(){
    alert('PREGUNTA CORRECTA --> 1/10');
}