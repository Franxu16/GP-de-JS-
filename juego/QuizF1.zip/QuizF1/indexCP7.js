function inicio(){
    alert('PREGUNTA CORRECTA --> 7/10');
}